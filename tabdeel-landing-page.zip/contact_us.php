<section id="contactus" style="background-image: url('images/pattern-bg.png');">
    <div class="container">
      <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6"><h4 class="text-center" style="padding: 10px;margin-top: 5px; background-color: #303192; color:#ffffff">Contact Us</h4></div>
        <div class="col-md-3"><hr></div>
      </div>
      <div class="row">
        <div class="col-md-5">
          <div class="card border-light mb-3">
            <!-- <div class="card-header border-light">Get in Touch!</div> -->
            <div class="card-body text-light">
              <h5 class="card-title">
                Consult Now
              </h5>
              <hr style="background-color: #ffffff; height:1px;">
              <form action="#" method="post">
                <label class="sr-only" for="servicetype">Service Type</label>
                  <div class="input-group mb-2 mr-sm-2">
                    <div class="input-group-prepend">
                      <div class="input-group-text" style="border:none; background-color: #EC0972; color:#ffffff"><i class="fas fa-question"></i></div>
                    </div>
                    <select id="servicetype" name="servicetype" class="form-control">
                      <option disabled selected>What is the enquiry about?</option>
                      <option disabled>------------</option>
                      <option value="webdevservicetype">Web Development</option>
                      <option value="graphicdesignservicetype">Graphic Design</option>
                      <option value="onlinecoursesservicetype">Online Courses</option>
                      <option value="trainingprogramservicetype">Training Program</option>
                    </select>
                  </div>
                <label class="sr-only" for="EmailIdInput">Email ID</label>
                  <div class="input-group mb-2 mr-sm-2">
                    <div class="input-group-prepend">
                      <div class="input-group-text" style="border:none; background-color: #EC0972; color:#ffffff"><i class="fas fa-envelope"></i></div>
                    </div>
                    <input type="email" class="form-control" id="EmailIdInput" name="EmailIdInput" placeholder="Email ID" required>
                  </div>
                  <label class="sr-only" for="contactNumberInput">Contact Number</label>
                  <div class="input-group mb-2 mr-sm-2">
                    <div class="input-group-prepend">
                      <div class="input-group-text" style="border:none; background-color: #EC0972; color:#ffffff"><i class="fas fa-phone"></i></div>
                    </div>
                    <input type="text" class="form-control" id="contactNumberInput" name="contactNumberInput" placeholder="Contact Number" required>
                  </div>
                 <!-- <label class="sr-only control-label" for="dtp_input1">DateTime Picking</label>
                  <div class="input-group mb-2 mr-sm-2">
                    <div class="input-group-prepend">
                      <div class="input-group-text" style="border:none; background-color: #EC0972; color:#ffffff"><i class="fas fa-calendar-alt"></i></div>
                    </div>
                    <div style="width:auto;" class="form-control input-group date form_datetime" data-date="2018-12-01T05:25:07Z" data-date-format="dd MM yyyy - HH:ii p" data-link-field="dtp_input1" style="display: inline;">
                      <input type="text" style="border:none;width:100%;" id="dateTimeInput" placeholder="When should we call?" value="" readonly>
                      <span class="input-group-addon" style="position: absolute;right:0;margin-right: 10px;"><i style="margin-right:10px;" class="glyphicon glyphicon-remove fas fa-times"></i><i class="glyphicon glyphicon-th fas fa-calendar-plus"></i></span>
                    </div>
                    <input type="hidden" id="dtp_input1" name="dtp_input1" value=""/>
                  </div> -->

                  <label class="sr-only" for="messageInput">Message</label>
                  <div class="input-group mb-2 mr-sm-2">
                    <div class="input-group-prepend">
                      <div class="input-group-text" style="border:none; background-color: #EC0972; color:#ffffff"><i class="fas fa-comment"></i></div>
                    </div>
                    <textarea class="form-control" id="messageInput" name="messageInput" rows="3" placeholder="How can we help you?" required></textarea>
                  </div>
                  <button type="submit" class="btn" name="submit_consult_form" style="margin-top:10px; background-color: #EC0972; color:#ffffff">Request a Quote</button>
                </form>
            </div>
          </div>
        </div>
        <div class="col-md-7" id="map" style="text-align: left;">
          <div style="position: relative;left:0;display: block">
            <div style="padding: 20px;padding-top:0; color:#ffffff">
              <div id="EmailInfo" style="padding: 10px;">
                <div style="background-color: #303192; display:inline; padding: 10px;">
                  <i class="fas fa-envelope"></i>
                </div>
                <div style="background-color: #EC0972; color:#ffffff; display:inline; padding: 10px;">
                  <h6 style="display: inline;">support@tabdeelstudios.com</h6>
                </div>
              </div>
              <div id="ContactInfo" style="padding: 10px;">
                <div style="background-color: #303192; display:inline; padding: 10px;">
                  <i class="fas fa-phone"></i>
                </div>
                <div style="background-color: #EC0972; color:#ffffff; display:inline; padding: 10px;">
                  <h6 style="display: inline;">+91 8220060505</h6>
                </div>
              </div>
              <hr>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3720.0344676442332!2d79.10771461441007!3d21.19078968760415!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd4c6cad457275b%3A0xb99312b44e7c8755!2sTabdeel+Studios+Training+and+Consultancy+(OPC)+Pvt+Ltd!5e0!3m2!1sen!2sin!4v1542791075946" width="100%" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
              </div>
            </div>
          </div>
          
        </div>
        
      </div>
     
    </div>
  </section>