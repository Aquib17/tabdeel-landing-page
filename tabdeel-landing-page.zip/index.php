<!doctype html>
  <head>
      <!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '1099996693528265');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=1099996693528265&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
    <?php
      include 'services/analytics.html';
    ?>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="We believe in first impressions. Tell us exactly what you want and we'll make it happen, together. A digital footprint escalates the change we aspire to instill. Through our services, we hope to be the enablers of change, letting you put your ideas into action and contribute your bit in driving the world forward.">
    <meta name="keywords" content="Web Development, Graphic Design, Online Courses, Training Programs, Website Revamp, Tabdeel Studios, BackToTheBasics">
    <meta name="author" content="Tabdeel Studios">
    <meta title="Tabdeel Studios | Web Development, Graphic Design, Online Courses, Training Programs">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link rel="apple-touch-icon" sizes="57x57" href="images/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="images/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="images/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="images/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="images/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="images/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="images/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="images/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="images/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="images/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="images/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon/favicon-16x16.png">
    <link rel="manifest" href="images/favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="images/favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <link rel="stylesheet" type="text/css" href="style.css">
    
    <link href="datetime/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
    <script src="https://use.fontawesome.com/15a5dd7984.js"></script>
    <title>Tabdeel Studios | Web Development, Graphic Design, Online Courses, Training Programs</title>

<script type="text/javascript">
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
          })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'ëV‚°', 'auto'); 
  ga('send', 'pageview'); 

</script>
  </head>
  <body>

    <?php

      include 'storing_leads.php';

    ?>
          
    <!-- NAVBAR -->
  <nav class="navbar navbar-expand-lg">
    <a class="navbar-brand" href="#">
      Tabdeel
      <img src="images/logo-white-without-text.png" width="30" height="30" class="d-inline-block align-top" alt="">
      Studios
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav">
    <i class="fas fa-lg fa-bars" style="color:#fff"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav mx-auto">
        <li class="nav-item">
          <a class="nav-link" href="#ourwhy">Our 'WHY'</a>
        </li>
        <!-- <li class="nav-item">
          <a class="nav-link" href="#meettheteam">Meet the team</a>
        </li> -->
        <li class="nav-item">
          <a class="nav-link" href="#howthisworks">How this works</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Services Offered
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="services/webdevservices.php">Web Development</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="services/graphicdesignservices.php">Graphic Design</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="services/onlinecourses.php">Online Courses</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="services/trainingprograms.php">Training Programs</a>
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#contactus">Contact Us</a>
        </li>
      </ul>
      <div>
        <a class="nav-link" style="display:inline;margin:0;padding:0;" target="_blank" href="http://www.facebook.com/TabdeelStudios">Find us on : <i class="fab fa-facebook-square fa-lg" aria-hidden="true"></i></a><a style="display:inline;padding:10px;margin:0;" class="nav-link" target="_blank" href="http://www.instagram.com/tabdeelstudios"><i class="fab fa-instagram fa-lg" aria-hidden="true"></i></a><a style="display:inline;padding:0;margin:0;" class="nav-link" target="_blank" href="https://www.linkedin.com/company/tabdeelstudios/"><i class="fab fa-linkedin fa-lg" aria-hidden="true"></i></a>
      </div>
    </div>

  </nav>
  
  <!-- HEADER -->
  <header>
    <img src="images/top-left.png" width="50px;">
    <div class="container">
      <div class="row">
        <div class="col-sm-8 col-12" style="margin-top:40px;"><hr>
          <h2 class="lead text-center" style="font-size: 28px;"><strong>We believe in first impressions. Tell us exactly what you want and we'll make it happen, together.</strong></h2><hr>
          <button onclick="getFocus()" class="btn btn-lg consult-now-header center-arrange">Consult Now</button>
        </div>
        <script type="text/javascript">
          function getFocus() {
              document.getElementById("EmailIdInput").focus();
          }
        </script>

        <div class="col-sm-4 col-12">
          <div class="horizontal div1">
              <div class="vertical">
                <img src="images/logo.png" class="tabdeel-logo mx-auto" width="275px">
              </div>
          </div>
        </div>
      </div>
    </div>
  </header>

  <!-- WHAT WE DO -->
  <section id="WhatWeDo">
    <div class="container">
      <div class="row">
        <div class="col-sm-3"><hr class="style12"></div>
        <div class="col-sm-6"><h4 class="text-center" style="padding: 10px;margin-top: 5px;">Our Services</h4></div>
        <div class="col-sm-3"><hr class="style12"></div>
      </div>
      <div class="row" style="padding: 20px;">
        <div class="col-sm-3 col-12 border-bottom-enable">
          <h5 class="text-center">Web Development</h5>
            <div class="horizontal div1">
              <div class="vertical">
                <img src="images/webdev.png" width="30%" style="margin:0 auto;">
                <a href="services/webdevservices.php" class="btn view-details-button" style="margin-top: 10px; margin-bottom:20px; margin-left:auto; margin-right:auto; width:50%">View More</a>
              </div>
            </div>
        </div>
        <div class="col-sm-3 col-12 border-bottom-enable">
          <h5 class="text-center">Graphic Design</h5>
            <div class="horizontal div1">
              <div class="vertical">
                <img src="images/graphicdesign.png" width="30%" style="margin:0 auto;">
                <a href="services/graphicdesignservices.php" class="btn view-details-button" style="margin-top: 10px; margin-bottom:20px; margin-left:auto; margin-right:auto; width:50%">View More</a>
              </div>
            </div>
        </div>
        <div class="col-sm-3 col-12 border-bottom-enable">
          <h5 class="text-center">Online Courses</h5>
            <div class="horizontal div1">
              <div class="vertical">
                <img src="images/onlinecourses.png" width="30%" style="margin:0 auto;">
                <a href="services/onlinecourses.php" class="btn view-details-button" style="margin-top: 10px; margin-bottom:20px; margin-left:auto; margin-right:auto; width:50%">View More</a>
              </div>
            </div>
        </div>
        <div class="col-sm-3 col-12 border-bottom-enable">
          <h5 class="text-center">Training Programs</h5>
            <div class="horizontal div1">
              <div class="vertical">
                <img src="images/trainingprograms.png" width="30%" style="margin:0 auto;">
                <a href="services/trainingprograms.php" class="btn view-details-button" style="margin-top: 10px; margin-bottom:20px; margin-left:auto; margin-right:auto; width:50%">View More</a>
              </div>
            </div>
        </div>
      </div>
     
    </div>
  </section>


  <section id="ourwhy" style="background-image: url('images/pattern-bg.png');">
    <div class="container">
      <div class="row" style="padding:30px;">
        <div class="col-sm-4 col-12">
          <h4 class="text-center" style="background-color: #303192; padding:10px; color:#ffffff;">Our WHY</h4><hr style="height:2px; background-color: #EC0972">
          <p class="lead text-center" style="font-weight: 500; font-size: 18px;">At present, a system exists for everything. And so, if there's anything wrong in the society, the system is at fault to some extent. Our motto is not to establish but initiate some ‘tabdeeli’, or ‘transformation’, in the system, for a better tomorrow.</p>
          <hr style="height:2px; background-color: #EC0972">
        </div>
        <div class="col-sm-4 col-12">
          <h4 class="text-center" style="background-color: #303192; padding:10px; color:#ffffff;">Mission</h4><hr style="height:2px; background-color: #EC0972">
          <p class="lead text-center" style="font-weight: 500; font-size: 18px;">A digital footprint escalates the change we aspire to instill. Through our services, we hope to be the enablers of change, letting you put your ideas into action and contribute your bit in driving the world forward.</p>
          <hr style="height:2px; background-color: #EC0972">
        </div>
        <div class="col-sm-4 col-12">
          <h4 class="text-center" style="background-color: #303192; padding:10px; color:#ffffff;">Vision</h4><hr style="height:2px; background-color: #EC0972">
          <p class="lead text-center" style="font-weight: 500; font-size: 18px;">We envision a time, not too long from now, where the systems of society  have minimal flaws. Where new ideas are encouraged, be it in any walks of life and change is supported. Tabdeeli takes a hundred-fold reach to make a mark. Lets work together to make it happen.</p>
          <hr style="height:2px; background-color: #EC0972">
        </div>
      </div>
    </div>
  </section>

 <!--  <hr style="background-color: #303192; height: 5px;margin: 0;">
  <hr style="background-color: #EC0972; height: 5px;margin: 0;"> -->

  <!-- <section id="meettheteam">
    <div class="container">
      <div class="row">
        <div class="card-group">
          <div class="card">
            <img class="card-img-top" src="images/team.jpg" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
            </div>
            <div class="card-footer">
              <small class="text-muted">Last updated 3 mins ago</small>
            </div>
          </div>
          <div class="card">
            <img class="card-img-top" src="images/team.jpg" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
            </div>
            <div class="card-footer">
              <small class="text-muted">Last updated 3 mins ago</small>
            </div>
          </div>
          <div class="card">
            <img class="card-img-top" src="images/team.jpg" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
            </div>
            <div class="card-footer">
              <small class="text-muted">Last updated 3 mins ago</small>
            </div>
          </div>
          <div class="card">
            <img class="card-img-top" src="images/team.jpg" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
            </div>
            <div class="card-footer">
              <small class="text-muted">Last updated 3 mins ago</small>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>     

   <hr style="background-color: #303192; height: 5px;margin: 0;">
   <hr style="background-color: #EC0972; height: 5px;margin: 0;">
 -->
   <section id="howthisworks">
     <div class="container">
       <div class="row">
          <!-- <div class="col-md-1"></div> -->
          <div class="col-md-4"><hr class="style12"></div>
          <div class="col-md-4"><h4 class="text-center" style="padding: 10px;margin-top: 5px;">How this works?</h4></div>
          <div class="col-md-4"><hr class="style12"></div>
          <!-- <div class="col-md-1"></div> -->
        </div>
        <div class="row">
          <div class="col-lg-3 col-md-6 col-sm-12">
            <hr style="background-color: #ffffff; height:2px;">
            <p style="background-color: #EC0972" class="content border-top-0"><span class="internal-content">Requirements</span></p>
            <p>Tell us exactly what you want. We will do our homework and get back to you with a Quotation and a Requirements document.</p>
            <hr style="background-color: #ffffff; height:2px;">
          </div>
          <div class="col-lg-3 col-md-6 col-sm-12">
            <hr style="background-color: #ffffff; height:2px;">
            <p style="background-color: #EC0972" class="content border-top-0"><span class="internal-content">Development</span></p>
            <p>We design a wireframe based on the finalised Requirements and get your approval before proceeding to the actual development.</p>
            <hr style="background-color: #ffffff; height:2px;">
          </div>
          <div class="col-lg-3 col-md-6 col-sm-12">
            <hr style="background-color: #ffffff; height:2px;">
            <p style="background-color: #EC0972" class="content border-top-0"><span class="internal-content">Testing</span></p>
            <p>We test everything internally during the development process. We recommend double-testing everything before putting it online.</p>
            <hr style="background-color: #ffffff; height:2px;">
          </div>
          <div class="col-lg-3 col-md-6 col-sm-12">
            <hr style="background-color: #ffffff; height:2px;">
            <p style="background-color: #EC0972" class="content border-top-0"><span class="internal-content">Deployment</span></p>
            <p>After everything is buttoned up, it is finally time to put it online and get your idea out there. Not sure how? Don't worry, we've got you covered.</p>
            <hr style="background-color: #ffffff; height:2px;">
          </div>
        </div>
        
     </div>
   </section>
<!--
   <section class="jumbotron" id="ourclients" style="margin-bottom: 0;padding:0 10px;">
      <div class="container">
        <div class="row">
          <div class="col-lg-2 col-md-6 col-sm-12">
            <img src="images/clients/facelogo.jpg" class="img-fluid" alt="Face Corporates Logo">
          </div>
          <div class="col-lg-2 col-md-6 col-sm-12">
            <img src="images/clients/glamaromalogo.jpg" class="img-fluid" alt="Glamaroma logo">
          </div>
          <div class="col-lg-2 col-md-6 col-sm-12">
            <img src="images/clients/quizzoralogo.jpg" class="img-fluid" alt="Quizzora logo">
          </div>
          <div class="col-lg-2 col-md-6 col-sm-12">
            <img src="images/clients/charminarlogo.jpg" class="img-fluid" alt="Charminar Masale logo">
          </div>
          <div class="col-lg-2 col-md-6 col-sm-12">
            <img src="images/clients/pencilstorylogo.jpg" class="img-fluid" alt="Pencil Story logo">
          </div>
          <div class="col-lg-2 col-md-6 col-sm-12">
            <img src="images/clients/teachpad.jpg" class="img-fluid" alt="Teachpad logo">
          </div>
        </div>
      </div>
   </section>
-->
   <hr style="background-color: #303192; height: 5px;margin: 0;">
   <hr style="background-color: #EC0972; height: 5px;margin: 0;">

   <?php
    include 'contact_us.php';
   ?>


  <!-- Back to top button -->
  <div>
     <button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fa fa-angle-double-up fa-lg" aria-hidden="true"></i></button>
    </div>
  
     </div>
   </section>

<?php
  
  include 'footer.html';
  
?>